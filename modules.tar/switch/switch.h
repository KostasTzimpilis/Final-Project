//=====[#include guards - begin]===============================================

#ifndef _SWITCH_H_
#define _SWITCH_H_

//=====[Declaration of public defines]=========================================


//=====[Declarations (prototypes) of public functions]=========================

void switchInit();

bool isDoorClosed();

bool isDoorOpen();

//=====[#include guards - end]=================================================

#endif // _SWITCH_H_
