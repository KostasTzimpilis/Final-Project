//=====[#include guards - begin]===============================================


#ifndef _START_BUTTON_H_
#define _START_BUTTON_H_


//=====[Declaration of public defines]=========================================


//=====[Declaration of public data types]======================================


//=====[Declarations (prototypes) of public functions]=========================


void startButtonInit();
void startButtonUpdate();
bool startButtonRead();


//=====[#include guards - end]=================================================


#endif // _START_BUTTON_H_
